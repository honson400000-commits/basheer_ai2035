'use client'

import { FormEvent, useEffect, useState } from 'react'

type Language = 'en' | 'ar'

const copy = {
  en: {
    direction: 'ltr',
    navLabel: 'Main navigation',
    platform: 'Platform',
    security: 'Security',
    pricing: 'Pricing',
    request: 'Request Access',
    signin: 'Sign in',
    eyebrow: 'SOVEREIGN LEGAL INTELLIGENCE',
    title: 'THE SOVEREIGN LEGAL INTELLIGENCE FOR SAUDI ARABIA',
    subtitle: 'Empowering Saudi legal teams with generative AI — compliant, secure, and built for Vision 2030.',
    primary: 'Request Access',
    secondary: 'Explore the platform',
    badges: ['SDAIA Aligned', 'PDPL Compliant', 'ISO 27001'],
    ask: 'Ask BASHEER',
    assistant: 'Your sovereign legal copilot',
    live: 'LIVE',
    prompt: 'Draft a non-disclosure agreement compliant with Saudi Companies Law, Article 45.',
    generated: 'Agreement draft generated',
    reviewed: 'Reviewed against PDPL and Labor Law',
    note: 'Key clauses: confidentiality, termination, jurisdiction: Saudi courts',
    response: 'Response time',
    accuracy: 'Accuracy',
    regulations: 'Regulations',
    stats: [['500+', 'Law Firms'], ['40%', 'Faster'], ['10K+', 'Regulations'], ['99.9%', 'Uptime']],
    pricingEyebrow: 'BUILT FOR THE KINGDOM',
    pricingTitle: 'Legal intelligence, sovereign by design.',
    pricingText: 'One secure command center for every legal team ready to move with confidence.',
    plan: 'BASHEER PRO',
    month: 'SAR / month',
    features: ['Saudi legal research and analysis', 'Instant drafting and contract review', 'Private, PDPL-ready workspace', 'Priority support for your team'],
    pay: 'Start with BASHEER',
    footerBadges: ['SDAIA Aligned', 'PDPL Compliant', 'ISO 27001', 'Cloud hosted in KSA'],
    footer: 'Built for Saudi Arabia. Ready for Vision 2030.',
    email: 'Work email',
    submit: 'Get early access',
    success: 'You are on the early access list.',
  },
  ar: {
    direction: 'rtl',
    navLabel: 'التنقل الرئيسي',
    platform: 'المنصة',
    security: 'الأمان',
    pricing: 'الأسعار',
    request: 'اطلب الوصول',
    signin: 'تسجيل الدخول',
    eyebrow: 'الذكاء القانوني السيادي',
    title: 'العقل القانوني الأقوى في المملكة — مصمم للسعودية',
    subtitle: 'نمكّن الفرق القانونية السعودية من الذكاء الاصطناعي التوليدي — آمن، دقيق، ومتوافق مع رؤية 2030.',
    primary: 'اطلب الوصول',
    secondary: 'اكتشف المنصة',
    badges: ['متوافق مع SDAIA', 'متوافق مع PDPL', 'ISO 27001'],
    ask: 'اسأل بشير',
    assistant: 'مساعدك القانوني السيادي',
    live: 'مباشر',
    prompt: 'صِغ اتفاقية عدم إفصاح متوافقة مع نظام الشركات السعودي، المادة 45.',
    generated: 'تم إنشاء مسودة الاتفاقية',
    reviewed: 'تمت مراجعتها وفق PDPL ونظام العمل',
    note: 'البنود الرئيسية: السرية، الإنهاء، الاختصاص القضائي: محاكم المملكة',
    response: 'زمن الاستجابة',
    accuracy: 'الدقة',
    regulations: 'الأنظمة',
    stats: [['500+', 'مكتب محاماة'], ['40%', 'أسرع'], ['10K+', 'نظام ولائحة'], ['99.9%', 'جاهزية']],
    pricingEyebrow: 'مصمم للمملكة',
    pricingTitle: 'ذكاء قانوني سيادي بتصميم سعودي.',
    pricingText: 'مركز قيادة آمن لكل فريق قانوني يتحرك بثقة وسرعة.',
    plan: 'بشير برو',
    month: 'ريال / شهرياً',
    features: ['بحث وتحليل قانوني سعودي', 'صياغة ومراجعة العقود فورياً', 'مساحة عمل خاصة ومتوافقة مع PDPL', 'دعم أولوية لفريقك'],
    pay: 'ابدأ مع بشير',
    footerBadges: ['متوافق مع SDAIA', 'متوافق مع PDPL', 'ISO 27001', 'مستضاف في السعودية'],
    footer: 'صُنع للسعودية. جاهز لرؤية 2030.',
    email: 'البريد الإلكتروني للعمل',
    submit: 'احصل على الوصول المبكر',
    success: 'تم تسجيلك في قائمة الوصول المبكر.',
  },
} as const

export default function Page() {
  const [language, setLanguage] = useState<Language>('ar')
  const [submitted, setSubmitted] = useState(false)
  const t = copy[language]

  useEffect(() => {
    document.documentElement.lang = language
    document.documentElement.dir = t.direction
  }, [language, t.direction])

  function handleSubmit(event: FormEvent<HTMLFormElement>) {
    event.preventDefault()
    setSubmitted(true)
  }

  return (
    <main className="sovereign-page min-h-screen overflow-hidden text-white" dir={t.direction}>
      <div className="sovereign-glow" aria-hidden="true" />
      <nav className="sovereign-nav" aria-label={t.navLabel}>
        <a className="brand-lockup" href="#top" aria-label="Basheer AI home"><span className="brand-mark">B</span><span><strong>BASHEER</strong><small>AI 2026</small></span></a>
        <div className="nav-links"><a href="#platform">{t.platform}</a><a href="#security">{t.security}</a><a href="#pricing">{t.pricing}</a></div>
        <div className="nav-actions"><button className="language-toggle" type="button" onClick={() => setLanguage(language === 'ar' ? 'en' : 'ar')} aria-label={language === 'ar' ? 'Switch to English' : 'التبديل إلى العربية'}>{language === 'ar' ? 'EN' : 'عربي'}</button><a className="nav-signin" href="#join">{t.signin}</a><a className="nav-access" href="#pricing">{t.request}</a></div>
      </nav>

      <section id="top" className="sovereign-hero" aria-labelledby="hero-heading">
        <div className="hero-copy"><p className="eyebrow">{t.eyebrow}</p><h1 id="hero-heading">{t.title}</h1><p className="hero-description">{t.subtitle}</p><div className="hero-actions"><a className="gold-button" href="#pricing">{t.primary} <span aria-hidden="true">→</span></a><a className="outline-button" href="#platform">{t.secondary}</a></div><div id="security" className="safeguards">{t.badges.map((item) => <span key={item}>{item}</span>)}</div></div>
        <div id="platform" className="ai-card" aria-label={t.ask}><div className="ai-card-top"><div className="live-label"><span className="live-dot" />{t.ask}<small>{t.assistant}</small></div><span className="live-badge">{t.live}</span></div><div className="question">{t.prompt}</div><div className="ai-results"><p>{t.generated} <strong>✓</strong></p><p>{t.reviewed} <strong>✓</strong></p><small>{t.note}</small></div><div className="ai-metrics"><span><small>{t.response}</small><b>1.2s</b></span><span><small>{t.accuracy}</small><b>99.8%</b></span><span><small>{t.regulations}</small><b>10K+</b></span></div></div>
      </section>

      <section className="stats-grid" aria-label="Basheer AI statistics">{t.stats.map(([value, label]) => <div className="stat-card" key={label}><b>{value}</b><span>{label}</span></div>)}</section>

      <section id="pricing" className="pricing-section"><div className="pricing-copy"><p className="eyebrow">{t.pricingEyebrow}</p><h2>{t.pricingTitle}</h2><p>{t.pricingText}</p></div><div className="pricing-card"><span className="plan-label">{t.plan}</span><div className="price"><strong>199</strong><span>{t.month}</span></div><ul>{t.features.map((feature) => <li key={feature}><span>✓</span>{feature}</li>)}</ul><a className="gold-button pricing-button" href="/pay.html">{t.pay} <span aria-hidden="true">→</span></a></div></section>

      <section id="join" className="join-section"><div className="join-card"><p className="eyebrow">{t.eyebrow}</p><h2>{t.request}</h2><form className="email-form" onSubmit={handleSubmit}><label className="sr-only" htmlFor="email">{t.email}</label><input id="email" name="email" type="email" required placeholder={t.email} /><button type="submit">{t.submit}</button></form>{submitted && <p className="success-message" role="status">{t.success}</p>}</div></section>
      <footer className="sovereign-footer"><div className="footer-badges">{t.footerBadges.map((badge) => <span key={badge}>{badge}</span>)}</div><p>{t.footer}</p><small>© 2026 BASHEER AI</small></footer>
    </main>
  )
}
